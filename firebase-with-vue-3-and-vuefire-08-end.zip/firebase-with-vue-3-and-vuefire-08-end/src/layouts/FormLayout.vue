<script setup>
import BaseContainer from '@/components/base/BaseContainer.vue'
</script>

<template>
  <BaseContainer>
    <slot name="title" />
    <slot name="content" />
  </BaseContainer>
</template>

<style></style>
