<script setup></script>

<template>
  <v-checkbox />
</template>

<style></style>
