<script setup></script>

<template>
  <v-rating />
</template>

<style></style>
