<script setup></script>

<template>
  <v-img />
</template>

<style></style>
