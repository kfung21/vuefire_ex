<script setup></script>

<template>
  <v-form>
    <slot />
  </v-form>
</template>

<style></style>
