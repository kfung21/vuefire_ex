<script setup></script>

<template>
  <v-btn>
    <slot />
  </v-btn>
</template>

<style></style>
