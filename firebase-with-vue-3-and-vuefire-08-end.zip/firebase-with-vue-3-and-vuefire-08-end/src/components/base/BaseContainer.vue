<script setup></script>

<template>
  <v-container>
    <slot />
  </v-container>
</template>

<style></style>
