<script setup></script>

<template>
  <v-icon />
</template>

<style></style>
