<script setup>
import NavItems from './NavItems.vue'
</script>

<template>
  <v-app-bar color="teal">
    <v-app-bar-title>Vue Eats</v-app-bar-title>
    <v-spacer></v-spacer>
    <NavItems />
  </v-app-bar>
</template>

<style></style>
